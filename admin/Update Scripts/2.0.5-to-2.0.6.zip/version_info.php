<?php
return array(
    'current_version'=>'2.0.5',
    'update_version'=>'2.0.6'
);
