<?php
return array(
    'current_version'=>'2.0.6',
    'update_version'=>'2.0.7'
);
