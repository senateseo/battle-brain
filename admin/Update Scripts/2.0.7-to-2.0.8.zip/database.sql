UPDATE `tbl_settings` SET `message` = '2.0.8' WHERE `tbl_settings`.`type` = 'system_version';
CREATE TABLE `tbl_web_settings` (`id` INT NOT NULL AUTO_INCREMENT , `type` VARCHAR(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL , `message` TEXT NULL DEFAULT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `tbl_upload_languages` (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(512) NOT NULL , `file` VARCHAR(512) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
