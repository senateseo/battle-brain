<?php
return array(
'current_version'=>'2.0.7',
    'update_version'=>'2.0.8'
);
