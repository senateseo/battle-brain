UPDATE `tbl_settings` SET `message` = '1.0.8' WHERE `tbl_settings`.`type` = 'system_version';
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('payment_mode', '1');
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('payment_message', '1');
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('per_coin', '10');
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('coin_amount', '1');
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('coin_limit', '100');
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('difference_hours', '48');
TRUNCATE tbl_tracker
ALTER TABLE `tbl_tracker` ADD `status` TINYINT NOT NULL COMMENT '0-add, 1-deduct' AFTER `type`;
CREATE TABLE `tbl_payment_request` (`id` int(11) NOT NULL AUTO_INCREMENT, `user_id` int(11) NOT NULL, `uid` text NOT NULL, `payment_type` varchar(100) NOT NULL, `payment_address` varchar(225) NOT NULL, `payment_amount` varchar(20) NOT NULL, `coin_used` varchar(20) NOT NULL, `details` text NOT NULL, `status` tinyint(4) NOT NULL COMMENT '0-pending, 1-completed, 2-invalid details', `date` datetime NOT NULL, PRIMARY KEY (`id`), KEY `user_id` (`user_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
ALTER TABLE `tbl_bookmark` ADD `type` INT NOT NULL COMMENT '1-quiz_zone, 3-guess_the_word, 4-audio_question' AFTER `status`;
UPDATE `tbl_bookmark` SET `type` = '1'
CREATE TABLE `tbl_quiz_categories` (`id` int(11) NOT NULL AUTO_INCREMENT, `user_id` int(11) NOT NULL, `type` int(11) NOT NULL COMMENT '2-fun_n_learn, 3-guess_the_word, 4-audio_question', `type_id` int(11) NOT NULL, `category` int(11) NOT NULL, `subcategory` int(11) NOT NULL, PRIMARY KEY (`id`), KEY `user_id` (`user_id`), KEY `type` (`type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
