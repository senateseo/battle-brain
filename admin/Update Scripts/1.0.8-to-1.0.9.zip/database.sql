UPDATE `tbl_settings` SET `message` = '1.0.9' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_users` ADD `api_token` LONGTEXT NOT NULL AFTER `date_registered`;
INSERT INTO `tbl_settings` (`type`, `message`) VALUES ('payment_mode', '0');
