UPDATE `tbl_settings` SET `message` = '2.1.1' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_category` ADD `is_premium` TINYINT NOT NULL DEFAULT '0' COMMENT '0 - no , 1 - yes' AFTER `type`, ADD `coins` INT NOT NULL DEFAULT '0' AFTER `is_premium`;
CREATE TABLE tbl_user_category ( id INT NOT NULL AUTO_INCREMENT , user_id INT NOT NULL , category_id INT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB;
ALTER TABLE `tbl_user_category` ADD UNIQUE(`user_id`, `category_id`);
ALTER TABLE `tbl_subcategory` ADD is_premium TINYINT NOT NULL DEFAULT '0' COMMENT '0 - no , 1 - yes' AFTER status, ADD coins INT NOT NULL DEFAULT '0' AFTER is_premium;
CREATE TABLE tbl_user_subcategory ( id INT NOT NULL AUTO_INCREMENT , user_id INT NOT NULL , subcategory_id INT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB;
ALTER TABLE `tbl_user_subcategory` ADD UNIQUE(`user_id`, `subcategory_id`);