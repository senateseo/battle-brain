<?php
return array(
    'current_version'=>'1.0.9',
    'update_version'=>"2.0.0"
);
