UPDATE `tbl_settings` SET `message` = '2.0.0' WHERE `tbl_settings`.`type` = 'system_version';
