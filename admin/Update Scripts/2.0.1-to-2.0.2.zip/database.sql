UPDATE `tbl_settings` SET `message` = '2.0.2' WHERE `tbl_settings`.`type` = 'system_version';
CREATE TABLE `tbl_slider` (`id` int(11) NOT NULL AUTO_INCREMENT, `language_id` int(11) NOT NULL, `image` varchar(255) NOT NULL, `title` text NOT NULL, `description` text NOT NULL, PRIMARY KEY (`id`), KEY `language_id` (`language_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
INSERT INTO tbl_settings (type, message) SELECT * FROM (SELECT 'maths_quiz_mode' AS type, '1' AS message) AS temp WHERE NOT EXISTS ( SELECT type FROM tbl_settings WHERE type = 'maths_quiz_mode' ) LIMIT 1;
