UPDATE `tbl_settings` SET `message` = '2.1.0' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_users` ADD `remove_ads` TINYINT NOT NULL DEFAULT '0' AFTER `friends_code`;
